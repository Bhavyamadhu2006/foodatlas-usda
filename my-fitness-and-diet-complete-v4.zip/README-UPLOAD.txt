MY FITNESS & DIET — COMPLETE APP v4

Upload these files together to the root of your GitHub repository:
- index.html
- manifest.webmanifest
- sw.js
- apple-touch-icon-v4.png
- icon-v4-192.png
- icon-v4-512.png

After the GitHub commit, Vercel should redeploy automatically.

IMPORTANT FOR IPHONE ICON:
If the old app is already on your Home Screen, iOS may keep its old cached icon.
1. Delete the old Home Screen app/shortcut.
2. Wait for the new Vercel deployment to be Ready.
3. Open the site in Safari.
4. Share -> Add to Home Screen -> Add.

This v4 package uses brand-new icon filenames specifically to avoid the older cached icon URL.
